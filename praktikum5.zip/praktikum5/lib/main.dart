import'package:flutter/material.dart';
import'ui_view/PageTwo.dart';
import'ui_view/login.dart'; 
import'ui_view/signup.dart'; 

void main() => runApp(MyApp());

class MyApp extends StatelessWidget{
  //Thiswidgetistherootofyourapplication.
  @override
  Widget build(BuildContextcontext){ 
    return MaterialApp(
      title:'FlutterDemo',
      theme:ThemeData(
        primarySwatch:Colors.blue,
      ),
      home:MyHomePage1(),
    );
  }
}

class MyHomePage extends StatelessWidget{ 
  @override
  Widget build(BuildContext context){
  return Scaffold( 
    appBar:AppBar(
      title:Text("Navigator"),
    ),
    body:Row(
      mainAxisAlignment:MainAxisAlignment.center, 
      children:<Widget>[
        MaterialButton(
          color:Colors.yellow, 
          child:Text("Page2"), 
          onPressed:(){
            //dibuatberikutnya
            Navigator.push(context,MaterialPageRoute( 
                builder:(context)=>PageTwo()
                )
              );
            },
          ),
        ],
      )
    );
  }
}

class MyHomePage1 extends StatelessWidget{ 
  @override
  Widget build(BuildContext context){ 
    return Scaffold(
    backgroundColor:Colors.lightBlue, 
    body:Center(
      child:Column(
        mainAxisAlignment:MainAxisAlignment.center, 
        children:<Widget>[
          Icon(Icons.android,color:Colors.white,size:45,), 
          SizedBox(height:200,),
          Text("WelcometoFlutter",style:TextStyle(color: 
          Colors.white,fontSize:22)),
          SizedBox(height:10,),
          Text("Getreal-timeupdatesaboutwhat",style: 
          TextStyle(color:Colors.white,fontSize:18)),
          Text("materstoyou",style:TextStyle(color: 
          Colors.white,fontSize:18)),
          SizedBox(height:20,),MaterialButton
          (
            minWidth:210, 
            color:Colors.white,
            textColor:Colors.lightBlue,
            child:Text("SignUp",style:TextStyle(fontWeight: 
            FontWeight.bold,fontSize:18),),
            onPressed:(){
              Navigator.push(context,MaterialPageRoute(builder: 
              (context)=>SignUp()));
            },
          ),
          FlatButton(
            child:Text("Login",style:TextStyle(color: 
            Colors.white,fontWeight:FontWeight.bold,fontSize:18),),
            onPressed:(){
              Navigator.push(context,MaterialPageRoute(builder: 
              (context)=>Login()));
              },
            )
          ],
        ),
      ),
    );
  }
}
